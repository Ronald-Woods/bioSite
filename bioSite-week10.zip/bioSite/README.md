<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CSD 340 Web Development with HTML and CSS</title>
</head>
<body>
<h1>CSD 340 Web Development with HTML and CSS</h1>
    <h2>Contributors</h2>
    <ul>
        <li>Instructor: Vianelis Martinez</li>
        <li>Ronald Woods</li>
    </ul>

</body>
</html>
